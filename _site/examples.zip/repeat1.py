''' A simple repeat loop'''

for i in range(10):
    print('Hello')
