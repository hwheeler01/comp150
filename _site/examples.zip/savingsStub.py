'''stub for savings.py exercise.'''

def savingGrowth(deposit, interestPercentage, goal):
    '''Print the account balance for each year until it reaches
    or passes the goal.
    >>> savingGrowth(100, 8.0, 125)
    Year 0: $100.00
    Year 1: $108.00
    Year 2: $116.64
    Year 3: $125.97
    '''
    # code here!


    
savingGrowth(100, 8.0, 125)
