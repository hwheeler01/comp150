x = 3      # simple sequential code
y = x + 2  # updating two variables
y = 2*y        
x = y - x      
print(x, y)    
