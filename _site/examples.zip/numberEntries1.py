'''In this version number does not change.'''

items = ['red', 'orange', 'yellow', 'green']
number = 1
for item in items:
    print(number, item)
