def listOnOneLine(items):
    for item in items:
        print(item, end=' ')
    print()

listOnOneLine(['apple', 'banana', 'pear'])
print('This is probably better!')
