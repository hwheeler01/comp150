def f(x):      #Play Computer Functions Exercise          
    return x+4                  
print(f(3)*f(6))
