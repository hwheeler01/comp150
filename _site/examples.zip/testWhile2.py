i = 4 # variation on testWhile.py
while (i < 9):
    i = i+2
    print(i)
