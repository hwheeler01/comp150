outFile = open('sample2.txt', 'w')
outFile.write('My second output file!')
outFile.write('Write some more.')
outFile.close()
