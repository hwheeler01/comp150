for count in [1, 2, 3]:
    print(count)
    print('Yes' * count)
    print('Done counting.') # changed so indented
for color in ['red', 'blue', 'green']:
    print(color)
