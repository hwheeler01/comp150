'''Test yourself!  What happens?'''

i = 4 
while i < 9:
    print(i)
    i = i+2
