print(2, type(2))
print(3.5, type(3.5))
print([], type([]))
print(True, type(True))
print(None, type(None))

# code to put in a for-each loop for the Pattern Loop Exercise
