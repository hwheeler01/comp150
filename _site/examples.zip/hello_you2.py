'''Hello to you!  Illustrates sep with empty string in print.
'''

person = input('Enter your name: ')
print('Hello ', person, '!', sep='')
